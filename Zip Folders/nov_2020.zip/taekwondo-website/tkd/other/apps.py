from django.apps import AppConfig


class OtherConfig(AppConfig):
    name = 'other'
